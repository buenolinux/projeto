CREATE DATABASE lojavirtual2;

USE lojavirtual2;

CREATE TABLE tab_fornecedores(
	id_fornecedor INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	nome_fornecedor VARCHAR(50) NOT NULL,	
	telefone VARCHAR(15) NOT NULL,	
    ativo INT(1) NOT NULL
);


CREATE TABLE tab_categorias(
	id_categoria INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	nome_categoria VARCHAR(50) NOT NULL,
     ativo INT(1) NOT NULL
    
);

CREATE TABLE tab_cargos(
	id_cargo INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	nome_cargo VARCHAR(50) NOT NULL,
     ativo INT(1) NOT NULL
);
CREATE TABLE tab_animais(
	id_animal INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	nome_animal VARCHAR(50) NOT NULL,
     ativo INT(1) NOT NULL
);
CREATE TABLE tab_marcas(
	id_marca INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	nome_marca VARCHAR(50) NOT NULL,
     ativo INT(1) NOT NULL
);



CREATE TABLE tab_lotes(
	id_lote INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	datavencimento DATE NOT NULL,
    entradadata DATE NOT NULL,
     ativo INT(1) NOT NULL
);

CREATE TABLE tab_funcionarios(
    id_funcionario INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nome_funcionario VARCHAR(50) NOT NULL,
    sobrenome VARCHAR(100) NOT NULL,
    nomeusuario VARCHAR(50) NOT NULL,
    perfil INT(1) NOT NULL,
    senha VARCHAR(200) NOT NULL,
    id_cargo INT NOT NULL,
    ativo INT(1) NOT NULL,

    CONSTRAINT  fk_id_cargo
    FOREIGN KEY(id_cargo)
    REFERENCES tab_cargos(id_cargo)
);

CREATE TABLE tab_clientes (
  id_cliente int NOT  NULL PRIMARY KEY  AUTO_INCREMENT,
  nome_cliente varchar(20) NOT NULL,
  sobrenome varchar(50) NOT NULL,
  cpf varchar(15) NOT NULL,
  rg varchar(13) DEFAULT NULL,
  nascimento date DEFAULT NULL,
  sexo varchar(1) NOT NULL,
  email varchar(50) NOT NULL,
  senha varchar(200) NOT NULL,
  ativo INT(1) NOT NULL

); 


/*  ENDEREÇO DO CLIENTE */


 


CREATE TABLE tab_estados(
  id_estado INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
  nome_estado varchar(2) NOT NULL,
   ativo INT(1) NOT NULL

);

CREATE TABLE tab_cidades (
    id_cidade INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nome_cidade varchar(50) NOT NULL,
    id_estado INT NOT NULL,
     ativo INT(1) NOT NULL,

    CONSTRAINT  fk_id_estado
    FOREIGN KEY(id_estado)
    REFERENCES tab_estados(id_estado)

);

CREATE TABLE tab_bairros (
    id_bairro INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nome_bairro varchar(50) NOT NULL,
    id_cidade INT NOT NULL,
     ativo INT(1) NOT NULL,

    CONSTRAINT  fk_id_cidade
    FOREIGN KEY(id_cidade)
    REFERENCES tab_cidades(id_cidade)

);

 CREATE TABLE tab_logradouros(
  id_logradouro INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
  cep varchar(9) NOT NULL,
  logradouro varchar(100) NOT NULL,
  numero varchar(5) NOT NULL,
  id_bairro INT NOT NULL,

    CONSTRAINT  fk_id_barrio
    FOREIGN KEY(id_bairro)
    REFERENCES tab_bairros(id_bairro)


 );

CREATE TABLE tab_enderecos(
    id_endereco  INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    id_logradouro INT NOT NULL,
    id_bairro INT NOT NULL,
    id_cidade INT NOT NULL,
    id_estado INT NOT NULL,
    id_cliente int NOT NULL,

    CONSTRAINT  fk2_id_logradouro
    FOREIGN KEY(id_logradouro)
    REFERENCES tab_logradouros(id_logradouro),

    CONSTRAINT  fk2_id_barrio
    FOREIGN KEY(id_bairro)
    REFERENCES tab_bairros(id_bairro),

    CONSTRAINT  fk2_id_cidade
    FOREIGN KEY(id_cidade)
    REFERENCES tab_cidades(id_cidade),

    CONSTRAINT  fk2_id_estado
    FOREIGN KEY(id_estado)
    REFERENCES tab_estados(id_estado),

    CONSTRAINT  fk3_id_cliente
    FOREIGN KEY(id_cliente)
    REFERENCES tab_clientes(id_cliente)

);


/*_____________________________*/

CREATE TABLE tab_unidademedidas(
    id_unidademedida  INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nome_unidademedida VARCHAR(2) NOT NULL,
     ativo INT(1) NOT NULL
    
);


CREATE TABLE tab_produtos (
  id_produto int NOT NULL PRIMARY KEY AUTO_INCREMENT,
  nome_produto varchar(50) NOT NULL,
  id_fornecedor int NOT NULL,
  id_lote int NOT NULL,
  id_animal int NOT NULL,
  id_categoria int NOT NULL,
  id_marca int NOT NULL,
  id_unidademedida  INT  NULL,
  valorunidademedida INT(11)  NULL,
  preco decimal(10,2) NOT NULL,
  imagem varchar(50) NOT NULL,
  descricao text NOT NULL,
  tamanho VARCHAR(11)  NULL, 
  quantidade int(11) NOT NULL,
  ativo INT(1) NOT NULL,

    CONSTRAINT  fk_id_fornecedor
    FOREIGN KEY(id_fornecedor)
    REFERENCES tab_fornecedores(id_fornecedor),  

    CONSTRAINT  fk_id_lote
    FOREIGN KEY(id_lote)
    REFERENCES tab_lotes(id_lote),  

    CONSTRAINT  fk_id_animal
    FOREIGN KEY(id_animal)
    REFERENCES tab_animais(id_animal),  

    CONSTRAINT  fk_id_categoria
    FOREIGN KEY(id_categoria)
    REFERENCES tab_categorias(id_categoria),

    CONSTRAINT  fk_id_unidademedida
    FOREIGN KEY(id_unidademedida)
    REFERENCES tab_unidademedidas(id_unidademedida),

    CONSTRAINT  fk_id_marca
    FOREIGN KEY(id_marca)
    REFERENCES tab_marcas(id_marca)

);

CREATE TABLE tab_itens_pedidos(
    id_pedido int NOT NULL,
    id_produto int NOT NULL,
    id_cliente int NOT NULL,
    quantidade int NOT NULL,

    CONSTRAINT  fk_id_produto
    FOREIGN KEY(id_produto)
    REFERENCES tab_produtos(id_produto),

    CONSTRAINT  fk_id_cliente
    FOREIGN KEY(id_cliente)
    REFERENCES tab_clientes(id_cliente)

); 

/*
Site onde há informações sobre unidades de medida
https://www.educamaisbrasil.com.br/enem/matematica/unidades-de-medida

*/