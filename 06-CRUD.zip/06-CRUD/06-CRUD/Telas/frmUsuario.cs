﻿using _06_CRUD.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _06_CRUD.Telas
{
    public partial class frmUsuario : Form
    {
        Usuario usuarioLogado = new Usuario();
        public frmUsuario(Usuario usu)
        {

            InitializeComponent();
            usuarioLogado = usu;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvPessoas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void frmUsuario_Load(object sender, EventArgs e)
        {
            dgvUsusriosAtivados.DataSource = Usuario.BuscarTodosUsuariosAtivados();
            dgvUsusriosAtivados.Columns[0].Visible = false;
            dgvUsusriosAtivados.Columns[1].HeaderText = " Nome";
            dgvUsusriosAtivados.Columns[2].HeaderText = "E-mail";
            dgvUsusriosAtivados.Columns[3].Visible = false;
            dgvUsusriosAtivados.Columns[4].Visible = false;
            dgvUsusriosAtivados.Columns[5].HeaderText = "Nível";
            dgvUsusriosAtivados.Columns[6].Visible = false;
            dgvUsusriosAtivados.Columns[7].Visible = false;


            dgvUsusriosDesativados.DataSource = Usuario.BuscarTodosUsuariosDesativados();
            dgvUsusriosDesativados.Columns[0].Visible = false;
            dgvUsusriosDesativados.Columns[1].HeaderText = " Nome";
            dgvUsusriosDesativados.Columns[2].HeaderText = "E-mail";
            dgvUsusriosDesativados.Columns[3].Visible = false;
            dgvUsusriosDesativados.Columns[4].Visible = false;
            dgvUsusriosDesativados.Columns[5].HeaderText = "Nível";
            dgvUsusriosDesativados.Columns[6].Visible = false;
            dgvUsusriosDesativados.Columns[7].Visible = false;
        }

        private void dgvUsusriosDesativados_DoubleClick(object sender, EventArgs e)
        {
            if (dgvUsusriosDesativados.SelectedRows.Count > 0)
            {
                int id = Convert.ToInt32(dgvUsusriosDesativados.SelectedRows[0].Cells[0].Value.ToString());
                DialogResult Pergunta = MessageBox.Show("Deseja reativar essse usuário", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (Pergunta == DialogResult.Yes)
                {
                    try
                    {
                        Usuario Ativar = new Usuario(id,1);
                        Ativar.AtivarUsuario();
                        MessageBox.Show("Usuário ativado!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        toolStripSalvar.Enabled = true;
                        toolStripAtualizar.Enabled = false;
                        toolStripExcluir.Enabled = false;
                        toolStripCancelar.Visible = false;
                        LimpaDados();
                        dgvUsusriosAtivados.DataSource = Usuario.BuscarTodosUsuariosAtivados();
                        dgvUsusriosDesativados.DataSource = Usuario.BuscarTodosUsuariosDesativados();
                    }
                    catch (Exception)
                    {

                        throw;
                    }
                }
            }
            

        }

        private void LimpaDados()
        {
            txbId.Clear();
            txbNome.Clear();
            txbEmail.Clear();
            txbLogin.Clear();
            txbNome.Focus();
            cbbNivel.SelectedIndex = -1;
            dgvUsusriosAtivados.DefaultCellStyle.SelectionBackColor = Color.CornflowerBlue;
            dgvUsusriosDesativados.DefaultCellStyle.SelectionBackColor = Color.CornflowerBlue;

        }

        private void dgvUsusriosAtivados_Click(object sender, EventArgs e)
        {
            // Função click
            MostraUsuario();
        }
        private void MostraUsuario()
        {
            if (dgvUsusriosAtivados.SelectedRows.Count > 0)
            {
                txbId.Text = dgvUsusriosAtivados.SelectedRows[0].Cells[0].Value.ToString();
                txbNome.Text = dgvUsusriosAtivados.SelectedRows[0].Cells[1].Value.ToString();
                txbEmail.Text =  dgvUsusriosAtivados.SelectedRows[0].Cells[2].Value.ToString();
                txbLogin.Text =  dgvUsusriosAtivados.SelectedRows[0].Cells[7].Value.ToString();
                cbbNivel.SelectedIndex = Convert.ToInt32(dgvUsusriosAtivados.SelectedRows[0].Cells[5].Value.ToString());
                toolStripSalvar.Enabled = false;
                toolStripAtualizar.Enabled = true;
                toolStripExcluir.Enabled = true;
                toolStripCancelar.Visible = true;
                dgvUsusriosAtivados.DefaultCellStyle.SelectionBackColor = Color.Tomato;
            }
        }

        private void toolStripCancelar_Click(object sender, EventArgs e)
        {
            LimpaDados();
            toolStripSalvar.Enabled = true;
            toolStripAtualizar.Enabled = false;
            toolStripExcluir.Enabled = false;
            toolStripCancelar.Visible = false;

        }

        private void toolStripSalvar_Click(object sender, EventArgs e)
        {
            if (ValidaDados())
            {
                string senhaCrypto = Crypto.sha256encrypt("123");
                senhaCrypto = senhaCrypto.ToLower();
                string frase = "padrão";

                Usuario NovoUsuario = new Usuario(txbNome.Text,txbEmail.Text, txbLogin.Text,senhaCrypto,frase,cbbNivel.SelectedIndex,1);
                NovoUsuario.InsereUsuario();
                MessageBox.Show("Usuário inserido", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpaDados();
                dgvUsusriosAtivados.DataSource = Usuario.BuscarTodosUsuariosAtivados();
            }
        }

        private bool ValidaDados()
        {
            if (txbNome.Text == string.Empty)
            {
                MessageBox.Show("Digite o nome", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txbNome.Focus();
                return false;
            }

            if (txbEmail.Text == string.Empty)
            {
                MessageBox.Show("Digite o Email", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txbEmail.Focus();
                return false;
            }

            if (txbLogin.Text == string.Empty)
            {
                MessageBox.Show("Digite o login", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txbLogin.Focus();
                return false;
            }

            if (cbbNivel.SelectedIndex == -1)
            {
                MessageBox.Show("Digite o login", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cbbNivel.Focus();
                return false;
            }

            return true;

        }

        private void toolStripAtualizar_Click(object sender, EventArgs e)
        {
            if (ValidaDados())
            {
                Usuario Altera = new Usuario(int.Parse(txbId.Text), txbNome.Text,txbEmail.Text,txbLogin.Text,cbbNivel.SelectedIndex);
                Altera.AlteraUsuario();
                MessageBox.Show("Usuário alterado", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpaDados();
                dgvUsusriosAtivados.DataSource = Usuario.BuscarTodosUsuariosAtivados();
                toolStripSalvar.Enabled = true;
                toolStripAtualizar.Enabled = false;
                toolStripExcluir.Enabled = false;
                toolStripCancelar.Visible = false;
            }
        }
    }
}
