﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControleDeEstoque
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }
        // método para verificar se os campos estão vázios
        private Boolean VerificaVazio()
        {
            if (txbLogin.Text == string.Empty)
            {
                MessageBox.Show("Atenção, digite seu usuário!", "Sistema de Vandas", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txbLogin.Focus();
                return false;
            }
            if (txbSenha.Text == string.Empty)
            {
                MessageBox.Show("Atenção, digite sua senha!", "Sistema de Vendas", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txbSenha.Focus();
                return false;
            }
            return true;
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {

        }
    }
}
