/*
Exemplo de código para consultar informações detalhadas de um produto
*/

SELECT tab_produtos.nome_produto AS 'Nome do produto',
		tab_produtos.preco AS 'Preço',
        tab_marcas.nome_marca AS 'Marca',
        tab_lotes.datavencimento AS 'Data de vencimento',
        tab_fornecedores.nome_fornecedor AS 'Nome do fornecedor',
        tab_categorias.nome_categoria AS 'Categoria do produto',
        tab_animais.nome_animal AS 'Tipo de animal'
        FROM tab_produtos
        INNER JOIN tab_marcas
        ON tab_marcas.id_marca = tab_produtos.id_marca
        
        INNER JOIN tab_lotes
        ON tab_lotes.id_lote = tab_produtos.id_lote
        
        INNER JOIN tab_fornecedores
        ON tab_produtos.id_fornecedor = tab_fornecedores.id_fornecedor
        
        INNER JOIN tab_categorias
        ON tab_produtos.id_categoria = tab_categorias.id_categoria 
        
        INNER JOIN tab_animais
        ON tab_produtos.id_animal = tab_animais.id_animal

        /*_________________________________________________*/

        SELECT tab_produtos.nome_produto AS 'Nome do produto',
		tab_produtos.preco AS 'Preço',
        tab_produtos.valorunidademedida ,
        tab_unidademedidas.nome_unidademedida AS 'Unidade de medida',
        tab_marcas.nome_marca AS 'Marca',
        tab_lotes.datavencimento AS 'Data de vencimento',
        tab_fornecedores.nome_fornecedor AS 'Nome do fornecedor',
        tab_categorias.nome_categoria AS 'Categoria do produto',
        tab_animais.nome_animal AS 'Tipo de animal'
        FROM tab_produtos
        INNER JOIN tab_unidademedidas
        ON tab_unidademedidas.id_unidademedida = tab_produtos.id_unidademedida
        
        INNER JOIN tab_marcas
        ON tab_marcas.id_marca = tab_produtos.id_marca
        
        INNER JOIN tab_lotes
        ON tab_lotes.id_lote = tab_produtos.id_lote
        
        INNER JOIN tab_fornecedores
        ON tab_produtos.id_fornecedor = tab_fornecedores.id_fornecedor
        
        INNER JOIN tab_categorias
        ON tab_produtos.id_categoria = tab_categorias.id_categoria 
        
        INNER JOIN tab_animais
        ON tab_produtos.id_animal = tab_animais.id_animal