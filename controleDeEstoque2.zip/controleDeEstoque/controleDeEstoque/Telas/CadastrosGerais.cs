﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace controleDeEstoque.Telas
{
    public partial class CadastrosGerais : Form
    {
        public CadastrosGerais()
        {
            InitializeComponent();
        }

        private void CadastroFornecedor_Load(object sender, EventArgs e)
        {

        }

        private void txbNomeFornecedor_TextChanged(object sender, EventArgs e)
        {

        }

        private void rbNao_CheckedChanged(object sender, EventArgs e)
        {
            gbAlterar.Visible = false;
        }

        private void rbSim_CheckedChanged(object sender, EventArgs e)
        {
            gbAlterar.Visible = true;
        }

        private void rbFornecedor_CheckedChanged(object sender, EventArgs e)
        {
            gbFornecedor.Visible = true;
            gbCategoria.Visible = false;
        }

        private void rbCategoria_CheckedChanged(object sender, EventArgs e)
        {
            gbCategoria.Visible = true;
            //gbCategoria.Location = 486; 36;
            gbFornecedor.Visible = false;
        }
    }
}
