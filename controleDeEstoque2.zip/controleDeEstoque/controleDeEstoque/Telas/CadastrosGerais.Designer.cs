﻿
namespace controleDeEstoque.Telas
{
    partial class CadastrosGerais
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txbFornecedor = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbAnimal = new System.Windows.Forms.RadioButton();
            this.rbMarca = new System.Windows.Forms.RadioButton();
            this.rbCategoria = new System.Windows.Forms.RadioButton();
            this.rbFornecedor = new System.Windows.Forms.RadioButton();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.txbMarca = new System.Windows.Forms.Label();
            this.txbTelefone = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.gbFornecedor = new System.Windows.Forms.GroupBox();
            this.gbMarca = new System.Windows.Forms.GroupBox();
            this.gbAnimal = new System.Windows.Forms.GroupBox();
            this.txbAnimal = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnCadastrar = new System.Windows.Forms.Button();
            this.cbbAlterar = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.gbAlterar = new System.Windows.Forms.GroupBox();
            this.btnAtualizar = new System.Windows.Forms.Button();
            this.txbAlterar = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.rbNao = new System.Windows.Forms.RadioButton();
            this.rbSim = new System.Windows.Forms.RadioButton();
            this.gbCategoria = new System.Windows.Forms.GroupBox();
            this.txbCategoria = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.rbDepartamento = new System.Windows.Forms.RadioButton();
            this.gbDepartamento = new System.Windows.Forms.GroupBox();
            this.txbDepartamento = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.gbCargo = new System.Windows.Forms.GroupBox();
            this.txbCargos = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.rbCargo = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.gbFornecedor.SuspendLayout();
            this.gbMarca.SuspendLayout();
            this.gbAnimal.SuspendLayout();
            this.gbAlterar.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbCategoria.SuspendLayout();
            this.gbDepartamento.SuspendLayout();
            this.gbCargo.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome fornedor:";
            // 
            // txbFornecedor
            // 
            this.txbFornecedor.Location = new System.Drawing.Point(122, 28);
            this.txbFornecedor.Name = "txbFornecedor";
            this.txbFornecedor.Size = new System.Drawing.Size(100, 20);
            this.txbFornecedor.TabIndex = 1;
            this.txbFornecedor.TextChanged += new System.EventHandler(this.txbNomeFornecedor_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbCargo);
            this.groupBox1.Controls.Add(this.rbDepartamento);
            this.groupBox1.Controls.Add(this.rbAnimal);
            this.groupBox1.Controls.Add(this.rbMarca);
            this.groupBox1.Controls.Add(this.rbCategoria);
            this.groupBox1.Controls.Add(this.rbFornecedor);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(302, 165);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // rbAnimal
            // 
            this.rbAnimal.AutoSize = true;
            this.rbAnimal.Location = new System.Drawing.Point(25, 89);
            this.rbAnimal.Name = "rbAnimal";
            this.rbAnimal.Size = new System.Drawing.Size(59, 17);
            this.rbAnimal.TabIndex = 3;
            this.rbAnimal.TabStop = true;
            this.rbAnimal.Text = "Animal:";
            this.rbAnimal.UseVisualStyleBackColor = true;
            // 
            // rbMarca
            // 
            this.rbMarca.AutoSize = true;
            this.rbMarca.Location = new System.Drawing.Point(25, 66);
            this.rbMarca.Name = "rbMarca";
            this.rbMarca.Size = new System.Drawing.Size(58, 17);
            this.rbMarca.TabIndex = 2;
            this.rbMarca.TabStop = true;
            this.rbMarca.Text = "Marca:";
            this.rbMarca.UseVisualStyleBackColor = true;
            // 
            // rbCategoria
            // 
            this.rbCategoria.AutoSize = true;
            this.rbCategoria.Location = new System.Drawing.Point(25, 43);
            this.rbCategoria.Name = "rbCategoria";
            this.rbCategoria.Size = new System.Drawing.Size(73, 17);
            this.rbCategoria.TabIndex = 1;
            this.rbCategoria.TabStop = true;
            this.rbCategoria.Text = "Categoria:";
            this.rbCategoria.UseVisualStyleBackColor = true;
            this.rbCategoria.CheckedChanged += new System.EventHandler(this.rbCategoria_CheckedChanged);
            // 
            // rbFornecedor
            // 
            this.rbFornecedor.AutoSize = true;
            this.rbFornecedor.Location = new System.Drawing.Point(25, 20);
            this.rbFornecedor.Name = "rbFornecedor";
            this.rbFornecedor.Size = new System.Drawing.Size(82, 17);
            this.rbFornecedor.TabIndex = 0;
            this.rbFornecedor.TabStop = true;
            this.rbFornecedor.Text = "Fornecedor:";
            this.rbFornecedor.UseVisualStyleBackColor = true;
            this.rbFornecedor.CheckedChanged += new System.EventHandler(this.rbFornecedor_CheckedChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(159, 19);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 6;
            // 
            // txbMarca
            // 
            this.txbMarca.AutoSize = true;
            this.txbMarca.Location = new System.Drawing.Point(22, 26);
            this.txbMarca.Name = "txbMarca";
            this.txbMarca.Size = new System.Drawing.Size(70, 13);
            this.txbMarca.TabIndex = 5;
            this.txbMarca.Text = "Nome marca:";
            // 
            // txbTelefone
            // 
            this.txbTelefone.Location = new System.Drawing.Point(122, 64);
            this.txbTelefone.Name = "txbTelefone";
            this.txbTelefone.Size = new System.Drawing.Size(100, 20);
            this.txbTelefone.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Telefone:";
            // 
            // gbFornecedor
            // 
            this.gbFornecedor.Controls.Add(this.txbFornecedor);
            this.gbFornecedor.Controls.Add(this.txbTelefone);
            this.gbFornecedor.Controls.Add(this.label1);
            this.gbFornecedor.Controls.Add(this.label4);
            this.gbFornecedor.Location = new System.Drawing.Point(486, 12);
            this.gbFornecedor.Name = "gbFornecedor";
            this.gbFornecedor.Size = new System.Drawing.Size(302, 107);
            this.gbFornecedor.TabIndex = 9;
            this.gbFornecedor.TabStop = false;
            this.gbFornecedor.Visible = false;
            // 
            // gbMarca
            // 
            this.gbMarca.Controls.Add(this.textBox2);
            this.gbMarca.Controls.Add(this.txbMarca);
            this.gbMarca.Location = new System.Drawing.Point(486, 200);
            this.gbMarca.Name = "gbMarca";
            this.gbMarca.Size = new System.Drawing.Size(302, 53);
            this.gbMarca.TabIndex = 11;
            this.gbMarca.TabStop = false;
            this.gbMarca.Visible = false;
            // 
            // gbAnimal
            // 
            this.gbAnimal.Controls.Add(this.txbAnimal);
            this.gbAnimal.Controls.Add(this.label3);
            this.gbAnimal.Location = new System.Drawing.Point(486, 260);
            this.gbAnimal.Name = "gbAnimal";
            this.gbAnimal.Size = new System.Drawing.Size(302, 63);
            this.gbAnimal.TabIndex = 12;
            this.gbAnimal.TabStop = false;
            this.gbAnimal.Visible = false;
            // 
            // txbAnimal
            // 
            this.txbAnimal.Location = new System.Drawing.Point(158, 18);
            this.txbAnimal.Name = "txbAnimal";
            this.txbAnimal.Size = new System.Drawing.Size(100, 20);
            this.txbAnimal.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Nome animal:";
            // 
            // btnCadastrar
            // 
            this.btnCadastrar.Location = new System.Drawing.Point(348, 477);
            this.btnCadastrar.Name = "btnCadastrar";
            this.btnCadastrar.Size = new System.Drawing.Size(111, 23);
            this.btnCadastrar.TabIndex = 13;
            this.btnCadastrar.Text = "Cadastrar";
            this.btnCadastrar.UseVisualStyleBackColor = true;
            // 
            // cbbAlterar
            // 
            this.cbbAlterar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbAlterar.FormattingEnabled = true;
            this.cbbAlterar.Location = new System.Drawing.Point(22, 43);
            this.cbbAlterar.Name = "cbbAlterar";
            this.cbbAlterar.Size = new System.Drawing.Size(241, 21);
            this.cbbAlterar.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(54, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(163, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Selecione algum item para alterar";
            // 
            // gbAlterar
            // 
            this.gbAlterar.Controls.Add(this.btnAtualizar);
            this.gbAlterar.Controls.Add(this.txbAlterar);
            this.gbAlterar.Controls.Add(this.cbbAlterar);
            this.gbAlterar.Controls.Add(this.label5);
            this.gbAlterar.Location = new System.Drawing.Point(15, 278);
            this.gbAlterar.Name = "gbAlterar";
            this.gbAlterar.Size = new System.Drawing.Size(299, 163);
            this.gbAlterar.TabIndex = 16;
            this.gbAlterar.TabStop = false;
            this.gbAlterar.Visible = false;
            // 
            // btnAtualizar
            // 
            this.btnAtualizar.Location = new System.Drawing.Point(206, 120);
            this.btnAtualizar.Name = "btnAtualizar";
            this.btnAtualizar.Size = new System.Drawing.Size(75, 23);
            this.btnAtualizar.TabIndex = 17;
            this.btnAtualizar.Text = "Atualizar";
            this.btnAtualizar.UseVisualStyleBackColor = true;
            // 
            // txbAlterar
            // 
            this.txbAlterar.Location = new System.Drawing.Point(22, 85);
            this.txbAlterar.Name = "txbAlterar";
            this.txbAlterar.Size = new System.Drawing.Size(241, 20);
            this.txbAlterar.TabIndex = 16;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.rbNao);
            this.groupBox2.Controls.Add(this.rbSim);
            this.groupBox2.Location = new System.Drawing.Point(15, 183);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(299, 70);
            this.groupBox2.TabIndex = 17;
            this.groupBox2.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(54, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(131, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Deseja alterar algum item?";
            // 
            // rbNao
            // 
            this.rbNao.AutoSize = true;
            this.rbNao.Checked = true;
            this.rbNao.Location = new System.Drawing.Point(140, 51);
            this.rbNao.Name = "rbNao";
            this.rbNao.Size = new System.Drawing.Size(45, 17);
            this.rbNao.TabIndex = 1;
            this.rbNao.TabStop = true;
            this.rbNao.Text = "Não";
            this.rbNao.UseVisualStyleBackColor = true;
            this.rbNao.CheckedChanged += new System.EventHandler(this.rbNao_CheckedChanged);
            // 
            // rbSim
            // 
            this.rbSim.AutoSize = true;
            this.rbSim.Location = new System.Drawing.Point(49, 51);
            this.rbSim.Name = "rbSim";
            this.rbSim.Size = new System.Drawing.Size(42, 17);
            this.rbSim.TabIndex = 0;
            this.rbSim.Text = "Sim";
            this.rbSim.UseVisualStyleBackColor = true;
            this.rbSim.CheckedChanged += new System.EventHandler(this.rbSim_CheckedChanged);
            // 
            // gbCategoria
            // 
            this.gbCategoria.Controls.Add(this.txbCategoria);
            this.gbCategoria.Controls.Add(this.label2);
            this.gbCategoria.Location = new System.Drawing.Point(486, 125);
            this.gbCategoria.Name = "gbCategoria";
            this.gbCategoria.Size = new System.Drawing.Size(302, 69);
            this.gbCategoria.TabIndex = 18;
            this.gbCategoria.TabStop = false;
            this.gbCategoria.Visible = false;
            // 
            // txbCategoria
            // 
            this.txbCategoria.Location = new System.Drawing.Point(159, 19);
            this.txbCategoria.Name = "txbCategoria";
            this.txbCategoria.Size = new System.Drawing.Size(100, 20);
            this.txbCategoria.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nome categoria:";
            // 
            // rbDepartamento
            // 
            this.rbDepartamento.AutoSize = true;
            this.rbDepartamento.Location = new System.Drawing.Point(25, 112);
            this.rbDepartamento.Name = "rbDepartamento";
            this.rbDepartamento.Size = new System.Drawing.Size(95, 17);
            this.rbDepartamento.TabIndex = 4;
            this.rbDepartamento.TabStop = true;
            this.rbDepartamento.Text = "Departamento:";
            this.rbDepartamento.UseVisualStyleBackColor = true;
            // 
            // gbDepartamento
            // 
            this.gbDepartamento.Controls.Add(this.txbDepartamento);
            this.gbDepartamento.Controls.Add(this.label7);
            this.gbDepartamento.Location = new System.Drawing.Point(486, 344);
            this.gbDepartamento.Name = "gbDepartamento";
            this.gbDepartamento.Size = new System.Drawing.Size(302, 63);
            this.gbDepartamento.TabIndex = 13;
            this.gbDepartamento.TabStop = false;
            this.gbDepartamento.Visible = false;
            // 
            // txbDepartamento
            // 
            this.txbDepartamento.Location = new System.Drawing.Point(158, 18);
            this.txbDepartamento.Name = "txbDepartamento";
            this.txbDepartamento.Size = new System.Drawing.Size(100, 20);
            this.txbDepartamento.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(21, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Departamento:";
            // 
            // gbCargo
            // 
            this.gbCargo.Controls.Add(this.txbCargos);
            this.gbCargo.Controls.Add(this.label8);
            this.gbCargo.Location = new System.Drawing.Point(486, 413);
            this.gbCargo.Name = "gbCargo";
            this.gbCargo.Size = new System.Drawing.Size(302, 63);
            this.gbCargo.TabIndex = 14;
            this.gbCargo.TabStop = false;
            this.gbCargo.Visible = false;
            // 
            // txbCargos
            // 
            this.txbCargos.Location = new System.Drawing.Point(158, 18);
            this.txbCargos.Name = "txbCargos";
            this.txbCargos.Size = new System.Drawing.Size(100, 20);
            this.txbCargos.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 25);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Cargo:";
            // 
            // rbCargo
            // 
            this.rbCargo.AutoSize = true;
            this.rbCargo.Location = new System.Drawing.Point(25, 135);
            this.rbCargo.Name = "rbCargo";
            this.rbCargo.Size = new System.Drawing.Size(56, 17);
            this.rbCargo.TabIndex = 5;
            this.rbCargo.TabStop = true;
            this.rbCargo.Text = "Cargo:";
            this.rbCargo.UseVisualStyleBackColor = true;
            // 
            // CadastrosGerais
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 537);
            this.Controls.Add(this.gbCargo);
            this.Controls.Add(this.gbDepartamento);
            this.Controls.Add(this.gbCategoria);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.gbAlterar);
            this.Controls.Add(this.btnCadastrar);
            this.Controls.Add(this.gbAnimal);
            this.Controls.Add(this.gbMarca);
            this.Controls.Add(this.gbFornecedor);
            this.Controls.Add(this.groupBox1);
            this.Name = "CadastrosGerais";
            this.Text = "Cadastros Gerais";
            this.Load += new System.EventHandler(this.CadastroFornecedor_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbFornecedor.ResumeLayout(false);
            this.gbFornecedor.PerformLayout();
            this.gbMarca.ResumeLayout(false);
            this.gbMarca.PerformLayout();
            this.gbAnimal.ResumeLayout(false);
            this.gbAnimal.PerformLayout();
            this.gbAlterar.ResumeLayout(false);
            this.gbAlterar.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.gbCategoria.ResumeLayout(false);
            this.gbCategoria.PerformLayout();
            this.gbDepartamento.ResumeLayout(false);
            this.gbDepartamento.PerformLayout();
            this.gbCargo.ResumeLayout(false);
            this.gbCargo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txbFornecedor;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbAnimal;
        private System.Windows.Forms.RadioButton rbMarca;
        private System.Windows.Forms.RadioButton rbCategoria;
        private System.Windows.Forms.RadioButton rbFornecedor;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label txbMarca;
        private System.Windows.Forms.TextBox txbTelefone;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox gbFornecedor;
        private System.Windows.Forms.GroupBox gbMarca;
        private System.Windows.Forms.GroupBox gbAnimal;
        private System.Windows.Forms.TextBox txbAnimal;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCadastrar;
        private System.Windows.Forms.ComboBox cbbAlterar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox gbAlterar;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton rbNao;
        private System.Windows.Forms.RadioButton rbSim;
        private System.Windows.Forms.Button btnAtualizar;
        private System.Windows.Forms.TextBox txbAlterar;
        private System.Windows.Forms.GroupBox gbCategoria;
        private System.Windows.Forms.TextBox txbCategoria;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rbDepartamento;
        private System.Windows.Forms.GroupBox gbDepartamento;
        private System.Windows.Forms.TextBox txbDepartamento;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox gbCargo;
        private System.Windows.Forms.TextBox txbCargos;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton rbCargo;
    }
}